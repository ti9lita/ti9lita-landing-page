# Ti9lita Landing Page

This is a poetic landing page telling the story of Ti9lita — a real love story of joy, heartbreak, and memory.  

## How to Run Locally

1. Clone the repo or unzip this folder
2. Run `npm install`
3. Run `npm run dev` to start the local server