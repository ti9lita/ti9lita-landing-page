import React from "react";

export const Footer = () => (
  <footer className="p-4 text-center text-sm text-gray-500">
    &copy; 2025 Ti9lita. All rights reserved.
  </footer>
);